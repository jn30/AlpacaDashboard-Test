import uvicorn
import socket

def get_free_port():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('localhost', 0))
    port = s.getsockname()[1]
    s.close()
    return port

if __name__ == "__main__":
    port = 9999
    print(f"INFO: Using port {port}")
    uvicorn.run("main:app", host="0.0.0.0", port=port)
