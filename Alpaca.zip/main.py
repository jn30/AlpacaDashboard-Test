import sys
import json
import os
import math
import csv
import requests
import traceback
from datetime import datetime, timedelta
from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field, validator, ValidationError
from typing import Optional, List, Dict

from alpaca.trading.client import TradingClient
from alpaca.trading.models import TradeAccount, Position
from alpaca.trading.requests import OrderRequest, GetOrdersRequest
from alpaca.broker.requests import GetAccountActivitiesRequest
from alpaca.data.requests import StockLatestQuoteRequest, StockLatestTradeRequest
from alpaca.trading.enums import OrderSide, OrderType, TimeInForce
from alpaca.data.historical.stock import StockHistoricalDataClient
from alpaca.common.exceptions import APIError

# --- Configuration ---
if getattr(sys, 'frozen', False):
    # Running in a PyInstaller bundle
    # We need to find the actual executable's directory for persistent data
    EXECUTABLE_DIR = os.path.dirname(sys.executable)
    DATA_DIR = os.path.join(EXECUTABLE_DIR, "AlpacaDashboardData")
    BASE_DIR = sys._MEIPASS # Keep this for templates/static
else:
    # Running in a normal Python environment
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    DATA_DIR = os.path.join(BASE_DIR, "AlpacaDashboardData") # For development environment

API_KEY_FILE = os.path.join(DATA_DIR, "api_keys.json")
BASKET_FILE = os.path.join(DATA_DIR, "baskets.json")

# Define static and templates directories
static_dir = os.path.join(BASE_DIR, "static")
templates_dir = os.path.join(BASE_DIR, "templates")

# Create directories if they don't exist


# --- Globals ---
trading_client: Optional[TradingClient] = None
data_client: Optional[StockHistoricalDataClient] = None
templates = Jinja2Templates(directory=templates_dir)

# --- Pydantic Models ---
class ApiKeys(BaseModel):
    api_key: str
    secret_key: str
    paper: bool
    pin: Optional[str] = None
    last_access_timestamp: Optional[float] = None

class Baskets(BaseModel):
    baskets: Dict[str, List[Dict[str, str | float]]]

class BasketExecution(BaseModel):
    basket_name: str
    total_amount: float

# --- Helper Functions ---
def load_api_keys() -> Optional[ApiKeys]:
    if os.path.exists(API_KEY_FILE):
        try:
            with open(API_KEY_FILE, 'r') as f:
                return ApiKeys(**json.load(f))
        except (json.JSONDecodeError, ValidationError) as e:
            print(f"Error loading API keys from {API_KEY_FILE}: {e}", file=sys.stderr)
            return None
    return None

def save_api_keys(keys: ApiKeys):
    os.makedirs(os.path.dirname(API_KEY_FILE), exist_ok=True)
    with open(API_KEY_FILE, 'w') as f:
        json.dump(keys.dict(), f)

def get_baskets() -> Dict:
    print(f"Attempting to load baskets from: {BASKET_FILE}", file=sys.stderr)
    if os.path.exists(BASKET_FILE):
        try:
            with open(BASKET_FILE, 'r') as f:
                baskets_data = json.load(f)
                print(f"Successfully loaded baskets: {baskets_data}", file=sys.stderr)
                return baskets_data.get("baskets", {})
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON from {BASKET_FILE}: {e}", file=sys.stderr)
            return {}
    print(f"Basket file not found: {BASKET_FILE}", file=sys.stderr)
    return {}

def save_baskets(baskets: Baskets):
    print(f"Attempting to save baskets to: {BASKET_FILE}", file=sys.stderr)
    os.makedirs(os.path.dirname(BASKET_FILE), exist_ok=True)
    try:
        with open(BASKET_FILE, 'w') as f:
            json.dump(baskets.dict(), f)
        print(f"Successfully saved baskets.", file=sys.stderr)
    except Exception as e:
        print(f"Error saving baskets to {BASKET_FILE}: {e}", file=sys.stderr)

# --- App Initialization ---
app = FastAPI()
app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.on_event("startup")
def startup_event():
    global trading_client, data_client
    keys = load_api_keys()
    if keys:
        trading_client = TradingClient(api_key=keys.api_key, secret_key=keys.secret_key, paper=keys.paper)
        data_client = StockHistoricalDataClient(api_key=keys.api_key, secret_key=keys.secret_key)

# --- Frontend Routes ---
import time

@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    keys = load_api_keys()
    if not keys:
        return templates.TemplateResponse("setup.html", {"request": request})
    
    # Check for PIN and session timeout
    if keys.pin:
        current_time = time.time()
        # 15 minutes in seconds = 15 * 60 = 900
        if not keys.last_access_timestamp or (current_time - keys.last_access_timestamp > 900):
            return templates.TemplateResponse("pin_entry.html", {"request": request})
    
    return templates.TemplateResponse("index.html", {"request": request, "current_timestamp": datetime.now().timestamp()})

@app.get("/order-history", response_class=HTMLResponse)
async def order_history_page(request: Request):
    return templates.TemplateResponse("order_history.html", {"request": request})

# --- API Routes ---
class PinRequest(BaseModel):
    pin: str

@app.post("/api/validate_pin")
async def validate_pin_endpoint(pin_request: PinRequest):
    keys = load_api_keys()
    if not keys or not keys.pin:
        raise HTTPException(status_code=400, detail="PIN not set or API keys not configured.")

    if pin_request.pin == keys.pin:
        keys.last_access_timestamp = time.time()
        save_api_keys(keys)
        return JSONResponse({"message": "PIN validated successfully."})
    else:
        raise HTTPException(status_code=401, detail="Invalid PIN.")

@app.post("/api/keys")
def save_keys_endpoint(api_key: str = Form(...), secret_key: str = Form(...), paper: bool = Form(True), pin: Optional[str] = Form(None)):
    keys = ApiKeys(api_key=api_key, secret_key=secret_key, paper=paper, pin=pin)
    try:
        # Validate keys by making a simple API call
        temp_client = TradingClient(api_key=keys.api_key, secret_key=keys.secret_key, paper=keys.paper)
        temp_client.get_account()
        save_api_keys(keys)
        startup_event() # Re-initialize clients
        return JSONResponse({"message": "API keys saved successfully."})
    except APIError as e:
        raise HTTPException(status_code=400, detail=f"Invalid API keys: {e}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")

@app.post("/api/keys/reset")
async def reset_keys_endpoint():
    global trading_client, data_client
    if os.path.exists(API_KEY_FILE):
        os.remove(API_KEY_FILE)
    if os.path.exists(BASKET_FILE):
        os.remove(BASKET_FILE)
    trading_client = None
    data_client = None
    return {"message": "API keys and all user data have been reset."}

@app.get("/api/account")
def get_account():
    if not trading_client:
        raise HTTPException(status_code=400, detail="API keys not configured.")
    try:
        account: TradeAccount = trading_client.get_account()

        # Fetch total historical dividends
        api_keys = load_api_keys()
        if not api_keys:
            raise HTTPException(status_code=400, detail="API keys not loaded for direct request.")

        base_url = "https://paper-api.alpaca.markets" if api_keys.paper else "https://api.alpaca.markets"
        headers = {
            "accept": "application/json",
            "APCA-API-KEY-ID": api_keys.api_key,
            "APCA-API-SECRET-KEY": api_keys.secret_key
        }

        def get_all_activities(url):
            all_activities = []
            page_token = None
            while True:
                paginated_url = f"{url}&page_token={page_token}" if page_token else url
                response = requests.get(paginated_url, headers=headers)
                response.raise_for_status()
                data = response.json()
                if not data:
                    break
                all_activities.extend(data)
                page_token = data[-1].get('id')
                if not page_token:
                    break
            return all_activities

        total_url = f"{base_url}/v2/account/activities?activity_types=DIV&direction=desc&page_size=100"
        total_activities_data = get_all_activities(total_url)
        
        total_historical_dividends = 0
        for act_data in total_activities_data:
            try:
                total_historical_dividends += float(act_data.get('net_amount', 0))
            except (ValueError, TypeError):
                continue

        return {
            "portfolio_value": float(account.portfolio_value),
            "buying_power": float(account.buying_power),
            "cash": float(account.cash),
            "status": account.status.value,
            "currency": account.currency,
            "total_dividends": total_historical_dividends,
        }
    except APIError as e:
        print(f"Alpaca API Error in get_account: {e}", file=sys.stderr)
        raise HTTPException(status_code=500, detail=f"Alpaca API Error: {e}")
    except Exception as e:
        import traceback
        print(f"Unexpected error in get_account: {e}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")

@app.get("/api/dividends")
def get_dividends(basket_name: Optional[str] = None):
    if not trading_client:
        raise HTTPException(status_code=400, detail="API keys not configured.")
    
    try:
        api_keys = load_api_keys()
        if not api_keys:
            raise HTTPException(status_code=400, detail="API keys not loaded for direct request.")

        base_url = "https://paper-api.alpaca.markets" if api_keys.paper else "https://api.alpaca.markets"
        headers = {
            "accept": "application/json",
            "APCA-API-KEY-ID": api_keys.api_key,
            "APCA-API-SECRET-KEY": api_keys.secret_key
        }

        def get_all_activities(url):
            all_activities = []
            page_token = None
            while True:
                paginated_url = f"{url}&page_token={page_token}" if page_token else url
                response = requests.get(paginated_url, headers=headers)
                response.raise_for_status()
                data = response.json()
                if not data:
                    break
                all_activities.extend(data)
                page_token = data[-1].get('id')
                if not page_token:
                    break
            return all_activities

        all_baskets = get_baskets()
        if basket_name and basket_name in all_baskets:
            basket_symbols = {item['symbol'] for item in all_baskets[basket_name]}
        else:
            basket_symbols = {item['symbol'] for basket in all_baskets.values() for item in basket}

        # --- 1. Weekly Dividends for Basket ---
        today = datetime.today()
        start_of_week = today - timedelta(days=today.weekday())
        monday_str = start_of_week.strftime('%Y-%m-%d')
        
        weekly_url = (f"{base_url}/v2/account/activities?activity_types=DIV,DIVNRA&direction=desc&page_size=100"
                      f"&after={monday_str}")
        
        weekly_activities_data = get_all_activities(weekly_url)
        
        weekly_dividends = 0
        for act_data in weekly_activities_data:
            if act_data.get('symbol') in basket_symbols:
                try:
                    weekly_dividends += float(act_data.get('net_amount', 0))
                except (ValueError, TypeError):
                    continue

        # --- 2. Total Historical Dividends for Basket ---
        total_url = f"{base_url}/v2/account/activities?activity_types=DIV&direction=desc&page_size=100"
        total_activities_data = get_all_activities(total_url)
        
        total_historical_dividends = 0
        for act_data in total_activities_data:
            if act_data.get('symbol') in basket_symbols:
                try:
                    total_historical_dividends += float(act_data.get('net_amount', 0))
                except (ValueError, TypeError):
                    continue

        return {
            "weekly_dividends": weekly_dividends,
            "total_historical_dividends": total_historical_dividends,
        }

    except requests.exceptions.RequestException as e:
        print(f"Request error in get_dividends: {e}", file=sys.stderr)
        raise HTTPException(status_code=500, detail=f"Network or API request error: {e}")
    except Exception as e:
        import traceback
        print(f"Unexpected error in get_dividends: {e}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")

@app.get("/api/positions")
def get_positions():
    if not trading_client:
        raise HTTPException(status_code=400, detail="API keys not configured.")
    try:
        positions: List[Position] = trading_client.get_all_positions()
        return [
            {
                "symbol": p.symbol,
                "qty": float(p.qty),
                "market_value": float(p.market_value),
                "current_price": float(p.current_price),
                "unrealized_pl": float(p.unrealized_pl),
                "unrealized_intraday_pl": float(p.unrealized_intraday_pl),
                "unrealized_intraday_plpc": float(p.unrealized_intraday_plpc),
                "avg_entry_price": float(p.avg_entry_price),
            }
            for p in positions
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/orders")
async def get_orders_endpoint():
    if not trading_client:
        raise HTTPException(status_code=400, detail="API keys not configured.")
    try:
        all_baskets = get_baskets()
        symbol_to_basket = {}
        for basket_name, basket_items in all_baskets.items():
            for item in basket_items:
                symbol_to_basket[item['symbol']] = basket_name

        orders = trading_client.get_orders(filter=GetOrdersRequest(status='all', limit=100, nested=True))
        
        response_orders = []
        for order in orders:
            basket_name = symbol_to_basket.get(order.symbol, '')
            response_orders.append({
                "ticker": order.symbol,
                "when": order.submitted_at.isoformat() if order.submitted_at else '',
                "quantity": float(order.qty),
                "basket": basket_name if basket_name else str(order.id),
                "share_price": float(order.limit_price) if order.limit_price else 0.0,
                "order_total": float(order.qty) * float(order.limit_price) if order.limit_price and order.qty else 0.0
            })
        return response_orders
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# --- Basket Trading API ---
@app.get("/api/baskets")
def get_baskets_endpoint():
    return get_baskets()

@app.get("/api/validate_ticker/{symbol}")
def validate_ticker(symbol: str):
    if not trading_client:
        raise HTTPException(status_code=400, detail="API keys not configured.")
    try:
        asset = trading_client.get_asset(symbol)
        if not asset.tradable:
            raise HTTPException(status_code=400, detail=f"Asset {symbol} is not tradable.")
        return {"message": "Asset is tradable."}
    except APIError as e:
        raise HTTPException(status_code=404, detail=f"Asset {symbol} not found.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/baskets")
def save_baskets_endpoint(baskets: Baskets):
    try:
        save_baskets(baskets)
        return {"message": "Baskets saved successfully."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save baskets: {e}")

@app.post("/api/baskets/execute")
def execute_basket_endpoint(execution: BasketExecution):
    print(f"--- Handling Intelligent Buy request: {execution} ---")
    if not trading_client or not data_client:
        raise HTTPException(status_code=400, detail="API keys not configured or invalid")

    all_baskets = get_baskets()
    basket_definition = all_baskets.get(execution.basket_name)
    if not basket_definition:
        raise HTTPException(status_code=404, detail=f"Basket '{execution.basket_name}' not found.")

    try:
        current_positions: List[Position] = trading_client.get_all_positions()
        positions_map = {p.symbol: p for p in current_positions}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Could not fetch current positions: {e}")

    # Calculate current total value of assets *in the basket*
    current_total_basket_value = 0.0
    for item in basket_definition:
        if item['symbol'] in positions_map:
            current_total_basket_value += float(positions_map[item['symbol']].market_value)

    final_total_value = current_total_basket_value + execution.total_amount
    buy_deltas = []

    # First pass: determine ideal amount to buy for each asset
    for item in basket_definition:
        symbol = item['symbol']
        target_percentage = item['percentage']
        current_value = float(positions_map[symbol].market_value) if symbol in positions_map else 0.0
        
        target_value = final_total_value * (target_percentage / 100.0)
        amount_to_buy = target_value - current_value

        if amount_to_buy > 0:
            buy_deltas.append({'symbol': symbol, 'amount': amount_to_buy})

    # Normalize buy amounts to match the total investment amount
    total_positive_delta = sum(d['amount'] for d in buy_deltas)
    
    # Calculate deviation from target for all basket items
    deviations = []
    for item in basket_definition:
        symbol = item['symbol']
        target_percentage = item['percentage']
        current_value = float(positions_map[symbol].market_value) if symbol in positions_map else 0.0
        target_value = (current_total_basket_value + execution.total_amount) * (target_percentage / 100.0)
        deviation = target_value - current_value
        deviations.append({'symbol': symbol, 'deviation': deviation, 'target_value': target_value})

    # Sort by deviation in descending order (most underweight first)
    deviations.sort(key=lambda x: x['deviation'], reverse=True)

    final_orders = []
    remaining_amount = execution.total_amount

    for item_data in deviations:
        symbol = item_data['symbol']
        deviation = item_data['deviation']
        target_value = item_data['target_value']
        current_value = float(positions_map[symbol].market_value) if symbol in positions_map else 0.0

        if remaining_amount <= 0:
            break

        # Calculate how much is needed to reach target for this position
        amount_needed_for_target = max(0, target_value - current_value)

        # Allocate either the remaining_amount or the amount_needed_for_target, whichever is smaller
        amount_to_allocate = min(remaining_amount, amount_needed_for_target)

        if amount_to_allocate > 0:
            final_orders.append({'symbol': symbol, 'amount': amount_to_allocate})
            remaining_amount -= amount_to_allocate

    # If there's still remaining_amount (e.g., if all positions are overweight or at target),
    # distribute it proportionally based on target percentages among all basket items.
    # This handles the "and so on" part, ensuring all funds are used if possible.
    if remaining_amount > 0:
        total_target_percentage = sum(item['percentage'] for item in basket_definition)
        if total_target_percentage > 0:
            for item in basket_definition:
                if remaining_amount <= 0:
                    break
                proportional_amount = remaining_amount * (item['percentage'] / total_target_percentage)
                
                # Find if this symbol already has an order
                existing_order = next((order for order in final_orders if order['symbol'] == item['symbol']), None)
                
                if existing_order:
                    existing_order['amount'] += proportional_amount
                else:
                    final_orders.append({'symbol': item['symbol'], 'amount': proportional_amount})
                remaining_amount -= proportional_amount

    # Execute orders
    submitted_orders, failed_orders, skipped_orders = [], [], []
    for order in final_orders:
        symbol = order['symbol']
        amount = order['amount']
        try:
            quote_request = StockLatestQuoteRequest(symbol_or_symbols=symbol)
            latest_quote = data_client.get_stock_latest_quote(quote_request)
            price_to_use = None
            if hasattr(latest_quote[symbol], 'latest_trade') and latest_quote[symbol].latest_trade is not None and latest_quote[symbol].latest_trade.price > 0:
                price_to_use = latest_quote[symbol].latest_trade.price
            elif latest_quote[symbol].ask_price is not None and latest_quote[symbol].ask_price > 0:
                price_to_use = latest_quote[symbol].ask_price

            if price_to_use is None:
                latest_trade_request = StockLatestTradeRequest(symbol_or_symbols=symbol)
                latest_trade = data_client.get_stock_latest_trade(latest_trade_request)
                price_to_use = latest_trade[symbol].price

            if price_to_use is None or price_to_use <= 0:
                raise ValueError("Could not determine a valid price for the asset.")

            limit_price = round(price_to_use * 1.01, 2)
            print(f"Symbol: {symbol}, Amount: {amount}, Price to use: {price_to_use}, Limit Price: {limit_price}")

            qty = math.floor(amount / limit_price)

            if qty > 0:
                # Use raw requests to bypass potential alpaca-py library issues
                api_keys = load_api_keys()
                headers = {
                    "APCA-API-KEY-ID": api_keys.api_key,
                    "APCA-API-SECRET-KEY": api_keys.secret_key,
                    "Content-Type": "application/json"
                }
                url = "https://paper-api.alpaca.markets/v2/orders" if api_keys.paper else "https://api.alpaca.markets/v2/orders"
                
                payload = {
                    "symbol": symbol,
                    "qty": str(qty),
                    "side": "buy",
                    "type": "limit",
                    "time_in_force": "day",
                    "limit_price": str(limit_price)
                }

                response = requests.post(url, json=payload, headers=headers)
                
                if response.status_code == 200:
                    new_order_id = response.json()['id']
                    submitted_orders.append({"symbol": symbol, "order_id": new_order_id, "qty": qty})
                else:
                    failed_orders.append({"symbol": symbol, "error": response.text})
            else:
                skipped_orders.append({"symbol": symbol, "reason": f"Allocated amount ${amount:.2f} is less than one share."})
        except Exception as e:
            failed_orders.append({"symbol": symbol, "error": str(e)})

    return JSONResponse(content={
        "status": "Execution completed",
        "submitted": submitted_orders,
        "failed": failed_orders,
        "skipped": skipped_orders
    })

@app.get("/api/export/orders/{file_type}")
async def export_orders(file_type: str):
    if not trading_client:
        raise HTTPException(status_code=400, detail="API keys not configured.")
    try:
        orders = trading_client.get_orders(filter=GetOrdersRequest(status='all', limit=1000, nested=True))
        
        export_path = os.path.join(BASE_DIR, 'export')
        os.makedirs(export_path, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_name = f"order_history_{timestamp}.{file_type}"
        file_path = os.path.join(export_path, file_name)

        if file_type == "csv":
            with open(file_path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(["Symbol", "Timestamp", "Quantity", "Basket", "Share Price", "Order Total"])
                for order in orders:
                    writer.writerow([
                        order.symbol,
                        order.submitted_at.isoformat() if order.submitted_at else '',
                        float(order.qty),
                        '', # Basket info not readily available here
                        float(order.limit_price) if order.limit_price else 0.0,
                        float(order.qty) * float(order.limit_price) if order.limit_price and order.qty else 0.0
                    ])
        elif file_type == "json":
            with open(file_path, 'w') as f:
                json.dump([o.dict() for o in orders], f, indent=4, default=str)
        else:
            raise HTTPException(status_code=400, detail="Invalid file type.")

        return {"message": f"Successfully exported to {file_path}"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/export/baskets/{basket_name}")
async def export_baskets(basket_name: str):
    try:
        all_baskets = get_baskets()
        basket = all_baskets.get(basket_name)
        if not basket:
            raise HTTPException(status_code=404, detail=f"Basket '{basket_name}' not found.")

        export_path = os.path.join(BASE_DIR, 'export')
        os.makedirs(export_path, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_name = f"{basket_name}_{timestamp}.json"
        file_path = os.path.join(export_path, file_name)

        with open(file_path, 'w') as f:
            json.dump(basket, f, indent=4)

        return {"message": f"Successfully exported to {file_path}"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))